package pa2;

// This class is used just do maintain name and ids from a user
public class Item {
	public Integer id;
	public String name;
	Item(Integer id, String name){
		this.id = id;
		this.name = name;
	}
}
