package pa2;

/*  This class is used to manage similars users and 
 * maintain a predict list to print out.*/

public class User {
	public String gender, profession;
	public Integer id;

	// Constructor
	User(Integer id, String gender, String profession){
		this.id = id;
		this.gender = gender;
		this.profession = profession;
	}
	// setter and getters of a similars list


	
}
